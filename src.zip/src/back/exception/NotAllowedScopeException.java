package back.exception;

public class NotAllowedScopeException extends Exception {
    public NotAllowedScopeException() {
        super("Not allowed scope!");
    }
}
